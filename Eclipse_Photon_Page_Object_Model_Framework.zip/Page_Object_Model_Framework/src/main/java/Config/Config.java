package Config;

import org.openqa.selenium.WebDriver;

public class Config
{
    public static WebDriver driver;
    public Config(WebDriver driver)
    {
        this.driver = driver;
    }


}
